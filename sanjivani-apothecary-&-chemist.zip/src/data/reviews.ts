import { Review } from '../types';

export const REVIEWS: Review[] = [
  {
    id: 'rev-01',
    reviewer: 'Dr. Madhav Ranade',
    role: 'Consultant Cardiologist, KEM Hospital Pune',
    rating: 5,
    date: '2 weeks ago',
    comment: 'Sanjivani Apothecary is our preferred local pharmacy for high-potency cardiac medications. Their cold-chain integrity and strict prescription verification standards set an exemplary benchmark in Pune.',
    verified: true,
    productName: 'Telma 40 Tablet'
  },
  {
    id: 'rev-02',
    reviewer: 'Sunita Gokhale',
    role: 'Retired Teacher, Model Colony, Pune',
    rating: 5,
    date: '1 month ago',
    comment: 'My husband and I have been ordering our monthly hypertension and thyroid tablets from Sanjivani for over 6 years. Their 90-minute doorstep delivery on FC Road is truly dependable, and their pharmacists always review for interactions.',
    verified: true,
    productName: 'Thyronorm 50mcg Tablet'
  },
  {
    id: 'rev-03',
    reviewer: 'Amol Shinde',
    role: 'IT Professional, Hinjewadi Phase 1',
    rating: 5,
    date: '3 weeks ago',
    comment: 'Uploaded my father\'s prescription via WhatsApp at 9:30 PM after a hospital consultation. The pharmacist verified the doses, suggested bioequivalent generics that saved me ₹420, and delivered before 11 PM. Outstanding service!',
    verified: true,
    productName: 'Augmentin 625 Duo Tablet'
  },
  {
    id: 'rev-04',
    reviewer: 'Priya Nambiar',
    role: 'Mother of two, Kothrud, Pune',
    rating: 5,
    date: '1 week ago',
    comment: 'The pediatric suspension and thermometer arrived packed cleanly in sealed tamper-proof medical pouches. The dosage reminder calendar included in the order was so thoughtful.',
    verified: true,
    productName: 'Crocin 120 Paediatric Syrup'
  },
  {
    id: 'rev-05',
    reviewer: 'Vikas Bapat',
    role: 'Senior Citizen, Shivajinagar, Pune',
    rating: 5,
    date: '2 months ago',
    comment: 'The Omron BP monitor was calibrated by their dispensary team before handoff. They took the time to show me how to position the arm cuff properly. Authentic pharmacy with a human heart.',
    verified: true,
    productName: 'Omron HEM-7120 Digital BP Monitor'
  },
  {
    id: 'rev-06',
    reviewer: 'Dr. Anjali Kelkar',
    role: 'Pediatrician, Deccan Gymkhana, Pune',
    rating: 5,
    date: '3 months ago',
    comment: 'Always reliable for genuine infant nutritional formulas and nebulizer accessories. Having a registered pharmacist available 24x7 on call gives young parents tremendous peace of mind.',
    verified: true
  },
  {
    id: 'rev-07',
    reviewer: 'Tanmay Deshpande',
    role: 'Marathon Runner, Aundh',
    rating: 5,
    date: '3 weeks ago',
    comment: 'Great stock of authentic Ayurvedic supplements and recovery balms. The Volini gel and Shelcal tablets are always fresh batches with long expiry dates.',
    verified: true,
    productName: 'Volini Pain Relief Gel'
  },
  {
    id: 'rev-08',
    reviewer: 'Rupali Gadgil',
    role: 'Homemaker, Erandwane, Pune',
    rating: 5,
    date: '2 weeks ago',
    comment: 'I love their Health Club rewards points system! Saved ₹180 on my skincare and multivitamin order just by applying my loyalty points and the FIRSTMED20 code.',
    verified: true,
    productName: 'Becadexamin Softgel Capsule'
  },
  {
    id: 'rev-09',
    reviewer: 'Suresh Dandekar',
    role: 'Advocate, Pune District Court',
    rating: 4,
    date: '1 month ago',
    comment: 'Accu-Chek glucometer kit and strips delivered promptly. Packaging was intact, test strips had 18 months validity remaining. Highly satisfied with genuine products.',
    verified: true,
    productName: 'Accu-Chek Active Blood Glucose Meter'
  },
  {
    id: 'rev-10',
    reviewer: 'Meera Chordia',
    role: 'Graphic Designer, Viman Nagar',
    rating: 5,
    date: '2 weeks ago',
    comment: 'The digital prescription upload tracker is slick. You see exactly when the chemist is verifying the slip and when it gets packed. Makes medicine ordering hassle-free.',
    verified: true
  },
  {
    id: 'rev-11',
    reviewer: 'Girish Korde',
    role: 'Architect, Baner, Pune',
    rating: 5,
    date: '4 days ago',
    comment: 'The blood sugar and blood pressure tracker on their site is surprisingly useful! I logged my morning fasting readings and showed the clean chart to my physician.',
    verified: true
  },
  {
    id: 'rev-12',
    reviewer: 'Shobha Chitale',
    role: 'Senior Citizen, Sadashiv Peth, Pune',
    rating: 5,
    date: 'Yesterday',
    comment: 'Friendly and respectful staff. When one brand of my blood pressure medicine was out of stock, the pharmacist called to explain the identical salt substitute clearly. Pure trust.',
    verified: true,
    productName: 'Telma 40 Tablet'
  }
];
