import { Brand } from '../types';

export const BRANDS: Brand[] = [
  { id: 'brand-sun', name: 'Sun Pharma', country: 'India', specialty: 'Cardiology, Neurology, Diabetology', productCount: 18 },
  { id: 'brand-cipla', name: 'Cipla', country: 'India', specialty: 'Respiratory, Antibiotics, OTC', productCount: 16 },
  { id: 'brand-dr-reddy', name: "Dr. Reddy's", country: 'India', specialty: 'Gastroenterology, Oncology, Pain', productCount: 14 },
  { id: 'brand-abbott', name: 'Abbott Healthcare', country: 'USA / India', specialty: 'Nutrition, Diabetes, Thyroid', productCount: 12 },
  { id: 'brand-himalaya', name: 'Himalaya Wellness', country: 'India', specialty: 'Ayurveda, Personal Care, Baby Care', productCount: 15 },
  { id: 'brand-dabur', name: 'Dabur India', country: 'India', specialty: 'Herbal Tonics, Chyawanprash, Digestion', productCount: 12 },
  { id: 'brand-zydus', name: 'Zydus Cadila', country: 'India', specialty: 'Critical Care, Therapeutics', productCount: 10 },
  { id: 'brand-torrent', name: 'Torrent Pharma', country: 'India', specialty: 'Cardiovascular, CNS, Gastro', productCount: 9 },
  { id: 'brand-glenmark', name: 'Glenmark Pharma', country: 'India', specialty: 'Dermatology, Respiratory, ENT', productCount: 11 },
  { id: 'brand-mankind', name: 'Mankind Pharma', country: 'India', specialty: 'Antibiotics, Pain Management, Vitamins', productCount: 14 },
  { id: 'brand-alkem', name: 'Alkem Laboratories', country: 'India', specialty: 'Anti-infectives, Analgesics', productCount: 8 },
  { id: 'brand-lupin', name: 'Lupin Limited', country: 'India', specialty: 'Anti-TB, Diabetology, Asthma', productCount: 10 },
  { id: 'brand-baidyanath', name: 'Shree Baidyanath', country: 'India', specialty: 'Classical Ayurvedic Formulations', productCount: 9 },
  { id: 'brand-omron', name: 'Omron Healthcare', country: 'Japan', specialty: 'Digital BP Monitors & Nebulizers', productCount: 6 },
  { id: 'brand-dettol', name: 'Dettol (Reckitt)', country: 'UK / India', specialty: 'Antiseptics & Hygiene', productCount: 7 }
];
